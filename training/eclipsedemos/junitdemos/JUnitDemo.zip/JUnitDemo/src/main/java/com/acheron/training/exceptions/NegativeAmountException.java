package com.acheron.training.exceptions;

public class NegativeAmountException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NegativeAmountException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NegativeAmountException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}

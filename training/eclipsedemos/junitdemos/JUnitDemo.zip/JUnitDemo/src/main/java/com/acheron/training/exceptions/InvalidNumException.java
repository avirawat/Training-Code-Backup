package com.acheron.training.exceptions;

public class InvalidNumException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidNumException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidNumException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}

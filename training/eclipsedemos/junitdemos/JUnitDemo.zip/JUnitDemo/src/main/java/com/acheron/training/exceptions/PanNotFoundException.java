package com.acheron.training.exceptions;

public class PanNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PanNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PanNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}

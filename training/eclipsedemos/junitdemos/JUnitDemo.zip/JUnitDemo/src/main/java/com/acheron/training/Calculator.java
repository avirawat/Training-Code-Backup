package com.acheron.training;

public class Calculator {
	
	public int sum(int x,int y) {
		return x+y;
	}
	public int product(int x,int y) {
		return x*y;
	}
	public String greet(String name) {
		return "WELCOME "+name.toUpperCase();
	}
}

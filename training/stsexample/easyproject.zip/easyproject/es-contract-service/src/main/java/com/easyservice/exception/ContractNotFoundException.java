/**
 *
 */
package com.easyservice.exception;

/**
 * @author TharunyaREDDY
 *
 */
public class ContractNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ContractNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ContractNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}

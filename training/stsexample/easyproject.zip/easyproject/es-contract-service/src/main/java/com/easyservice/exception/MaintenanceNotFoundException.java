/**
 *
 */
package com.easyservice.exception;

/**
 * @author TharunyaREDDY
 *
 */
public class MaintenanceNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MaintenanceNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MaintenanceNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}

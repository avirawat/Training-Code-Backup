package com.clinicapp.exceptions;

public class ClinicNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ClinicNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ClinicNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}

package com.greetapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringLoggingDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}

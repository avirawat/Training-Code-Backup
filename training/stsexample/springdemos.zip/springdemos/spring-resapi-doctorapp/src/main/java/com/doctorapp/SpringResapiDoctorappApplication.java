package com.doctorapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringResapiDoctorappApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringResapiDoctorappApplication.class, args);
	}

}

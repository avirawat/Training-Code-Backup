package com.studentapp;



//@Configuration
public class AppRunner{

	

}

package com.productapp.model;


//DTO projection using interface closed Projection
//this should have getter method of the instance variable
//can have one or more methods 

public interface PriceView {
	
	double getPrice();
}

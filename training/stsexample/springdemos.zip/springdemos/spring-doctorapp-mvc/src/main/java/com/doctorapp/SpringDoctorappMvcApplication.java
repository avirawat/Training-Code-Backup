package com.doctorapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDoctorappMvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringDoctorappMvcApplication.class, args);
	}

}

package com.acheron.model;

//retrievibg data from a view
public interface LeagueView {
	
	//create getter methods for column in view
	//column names should be in caps
	
	String getNAME();
	int getDURATION();
	String getCOUNTRY();
}

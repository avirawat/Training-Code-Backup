package com.acheron.model;

public interface SportView {
	
	String getSPORTNAME();
	String getLEAGUENAME();
	int getDURATION();
	String getMEMBERNAME();
	String getSQUAD();
	String getSTADIUM();
}

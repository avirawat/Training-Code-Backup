package com.acheron.model;

public interface TeamView {

}

package com.shristi.autowiring;

import org.springframework.stereotype.Component;

@Component
public interface Shape {
	
	void area(int length,int breadth);

}

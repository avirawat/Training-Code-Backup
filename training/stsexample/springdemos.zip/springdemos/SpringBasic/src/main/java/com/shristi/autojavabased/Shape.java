package com.shristi.autojavabased;

import org.springframework.stereotype.Component;

public interface Shape {
	
	void area(int length,int breadth);

}

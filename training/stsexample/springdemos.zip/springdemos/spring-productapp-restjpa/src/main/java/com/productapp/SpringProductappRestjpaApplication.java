package com.productapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringProductappRestjpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringProductappRestjpaApplication.class, args);
	}

}

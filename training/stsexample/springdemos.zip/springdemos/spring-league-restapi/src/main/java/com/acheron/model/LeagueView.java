package com.acheron.model;

//retrieving data from a view
public interface LeagueView {
	// create getter method for columns in view
// column names should be in caps	
	
	String getNAME();
	int getDURATION();
	String getCOUNTRY();
}

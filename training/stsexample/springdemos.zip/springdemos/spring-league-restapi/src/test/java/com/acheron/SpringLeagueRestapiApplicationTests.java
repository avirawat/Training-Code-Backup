package com.acheron;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringLeagueRestapiApplicationTests {

	@Test
	void contextLoads() {
	}

}

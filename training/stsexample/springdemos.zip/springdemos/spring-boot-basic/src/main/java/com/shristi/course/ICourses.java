package com.shristi.course;

import java.util.List;

public interface ICourses {
	
	List<String> printDetails();
}

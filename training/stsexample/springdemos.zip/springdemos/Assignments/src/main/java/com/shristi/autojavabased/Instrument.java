package com.shristi.autojavabased;

import org.springframework.stereotype.Component;


public interface Instrument {
	
	void play(String song);
}

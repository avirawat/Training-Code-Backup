package com.npd.controller;

public class MigrationController {

}

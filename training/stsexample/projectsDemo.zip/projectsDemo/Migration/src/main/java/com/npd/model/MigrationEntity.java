package com.npd.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MigrationEntity {
	
	private String projectNumber;
	private String market;
	private String brand;
}

package com.npd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MigrationApplicationTests {

	@Test
	void contextLoads() {
	}

}

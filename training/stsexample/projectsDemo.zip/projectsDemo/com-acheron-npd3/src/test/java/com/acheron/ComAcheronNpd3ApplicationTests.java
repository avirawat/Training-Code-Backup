package com.acheron;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComAcheronNpd3ApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.acheron.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AllDataEntity {
	
	private String projectNumber;
	private String market;
	private String brand;
}

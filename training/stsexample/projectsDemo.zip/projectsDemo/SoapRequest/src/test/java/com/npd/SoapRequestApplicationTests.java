//package com.npd;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//class SoapRequestApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}
//
//}

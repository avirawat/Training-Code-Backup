package com.npd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoapRequestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SoapRequestApplication.class, args);
	}

}

package com.easyservice.exception;

public class WorkerNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public WorkerNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public WorkerNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}

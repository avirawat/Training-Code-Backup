/**
 *
 */
package com.easyservice.model;

/**
 * @author TharunyaREDDY
 *
 */
public enum Status {
	DEFINED, INPROGRESS, COMPLETED, ONHOLD;
}

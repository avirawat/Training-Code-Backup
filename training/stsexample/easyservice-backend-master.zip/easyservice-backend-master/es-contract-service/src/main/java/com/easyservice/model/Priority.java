/**
 *
 */
package com.easyservice.model;

/**
 * @author TharunyaREDDY
 *
 */
public enum Priority {
	HIGH, LOW, MIDDLE;
}

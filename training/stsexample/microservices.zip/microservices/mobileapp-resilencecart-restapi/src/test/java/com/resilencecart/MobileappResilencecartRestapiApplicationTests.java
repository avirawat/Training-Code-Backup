package com.resilencecart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MobileappResilencecartRestapiApplicationTests {

	@Test
	void contextLoads() {
	}

}

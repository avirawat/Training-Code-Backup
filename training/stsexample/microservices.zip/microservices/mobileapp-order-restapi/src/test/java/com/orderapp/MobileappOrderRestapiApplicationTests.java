package com.orderapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MobileappOrderRestapiApplicationTests {

	@Test
	void contextLoads() {
	}

}

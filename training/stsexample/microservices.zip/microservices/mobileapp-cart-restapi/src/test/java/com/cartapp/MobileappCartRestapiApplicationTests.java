package com.cartapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MobileappCartRestapiApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.mobileapp.exception;

public class MobileNotFoundException extends RuntimeException  {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MobileNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MobileNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
	
}

package com.mobileapp.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MobileappEurekaRegistryApplicationTests {

	@Test
	void contextLoads() {
	}

}

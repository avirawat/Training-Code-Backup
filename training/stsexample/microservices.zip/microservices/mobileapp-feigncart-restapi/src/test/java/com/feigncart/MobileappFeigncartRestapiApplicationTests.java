package com.feigncart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MobileappFeigncartRestapiApplicationTests {

	@Test
	void contextLoads() {
	}

}

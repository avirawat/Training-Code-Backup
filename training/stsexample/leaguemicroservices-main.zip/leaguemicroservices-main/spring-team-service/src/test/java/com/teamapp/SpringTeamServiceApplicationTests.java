package com.teamapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringTeamServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}

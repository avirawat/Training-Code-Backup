package com.easyservice.model;

public enum Status {
	
	DEFINED, INPROGRESS, COMPLETED, ONHOLD;
}

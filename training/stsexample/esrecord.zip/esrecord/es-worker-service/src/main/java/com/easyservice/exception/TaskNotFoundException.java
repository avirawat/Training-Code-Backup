package com.easyservice.exception;

public class TaskNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public TaskNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TaskNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}

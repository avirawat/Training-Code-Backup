package com.easyservice.model;

public enum Priority {
	HIGH,LOW,MIDDLE;
}

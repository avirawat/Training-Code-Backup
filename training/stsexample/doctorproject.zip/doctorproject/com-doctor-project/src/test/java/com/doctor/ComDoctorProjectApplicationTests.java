package com.doctor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComDoctorProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}

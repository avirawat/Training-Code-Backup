package com.doctor.exceptions;

public class DoctorNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DoctorNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DoctorNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}

package com.doctorapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComDoctorappProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.doctorapp.exceptions;

public class HospitalNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public HospitalNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public HospitalNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
